﻿# patent_reader.vault

