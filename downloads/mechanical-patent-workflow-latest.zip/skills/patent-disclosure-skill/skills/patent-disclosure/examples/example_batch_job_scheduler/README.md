# 示例案件：分布式批任务调度与资源感知

本目录为**虚构教学案件**，仅保留 **`knowledge/`** 作为 **Step 2 扫描原材料**（设计文档、示例 Office、代码片段）。专利点、查新笔记、交底书等产出请在 Agent 全流程中生成到 **`outputs/{案件标识}/`**（见 [本包 examples/README.md](../README.md)）。

## 目录说明

| 路径 | 说明 |
|------|------|
| `knowledge/` | **虚构「项目原材料」**：架构说明、示例 Word/PPT（含图）、`.tex` 源码、调度示例代码，供 Step 2 与 Office→MD / LaTeX 读链演练 |
