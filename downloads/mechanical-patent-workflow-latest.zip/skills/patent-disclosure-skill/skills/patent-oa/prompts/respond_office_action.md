# 审查答复 · 审查文档 → 答复草稿

前置：配置已确认；**先检索再生成**。

## 输入（优先 PDF，禁止让用户手贴长文）

- **审查意见通知书 / 补正通知书 PDF**（用户给路径即可）  
- 可选：本申请权要/说明书 PDF 或摘录路径  
- 可选：专利类型、已知法条/缺陷标签  

Agent **必须**先跑抽取，不要让用户「先转文本再粘贴」。

```bash
# 仅抽取（可读全文做结构化）
python skills/patent-oa/tools/pdf_text.py -i path/to/office_action.pdf
# → 同目录 {stem}.extracted.txt + .json

# 抽取并直接检索（推荐）
python skills/patent-oa/tools/search_cases.py --pdf path/to/office_action.pdf \
  --patent-type invention \
  --statute "专利法第22条第3款" \
  --defect inventiveness \
  --top-k 5
```

扫描件若几乎无字：工具会 `WARN extracted_text_too_short`；告知用户换可复制文字的 PDF 或先 OCR，**仍不要**让用户手抄通知书。

## 步骤

### 1. 结构化解析

`Read` 抽取得到的 `.extracted.txt`（或 `--stdout` 预览），抽出：

- `notice_kind`、答复期限（若有）  
- 逐条缺陷：法条、审查员观点、对比文件号  
- `defect_types`、`statutes`、`patent_type`、`domain`（推断须标注）

可把结构化 YAML 落到 `outputs/oa/{案件}/notice_struct.yaml`。

### 2. 检索（必做）

优先 `--pdf`；已有抽取文件时可用 `--query-file …extracted.txt`。

```bash
python skills/patent-oa/tools/search_cases.py --pdf path/to/office_action.pdf \
  --patent-type invention \
  --statute "专利法第22条第3款" \
  --defect inventiveness \
  --top-k 5
# 强制仅标签：加 --tags-only
```

- 展示 `hits`，**每条带 `diff`**；同时告知 `retrieval_mode`（`vector` / `tags_only` / `tags_fallback`）。  
- 若 JSON 含 `rebuild_hint_zh`：向用户转述，确认后跑 `rebuild_vectors.py --confirm`。  
- 向量超时/失败时**不得中断**：用标签结果继续生成草稿。  
- 库为空：仍做同点短方案比较（不得用案例加分），按门槛选定后出一份提纲式草稿，禁止假装引用历史案。

### 3. 同点多策略评判（自动，不中断、不展示卡片）

**禁止**写稿前停下来等用户勾选。**禁止**做成策略卡片墙或「授权率」。后台对**每一条缺陷**比 2～3 路短方案，再按「分差 + 保范围门槛」定主策略，只对选定策略写完整草稿。

对每条缺陷至少比较（按通知书性质裁剪，形式缺陷可只留补正）：

- `仅意见陈述`（只争）  
- `修改权利要求`（含上提从属/限缩独权）  
- 可选：`修改说明书` 或 `补正形式`

每路只写：一句话打法、主要风险、是否超范围。**不要**为落选策略生成全文。

#### 评分目标（相对分 0～100，两维）

| 维度 | 含义 | 禁止 |
|------|------|------|
| `稳妥分` | 本条缺陷被克服的相对把握 | 不得写成授权率/授权概率 |
| `保范围分` | 权利要求保护范围保留程度 | 缩权不得靠把保范围分打满来「赢」 |

输入（写入内部评判，勿对用户堆原始 JSON）：通知书该条要点；命中案例的 `case_id`、`diff`、`outcome`；若 `retrieval_mode` 含向量则附带该 hit 的相似度分。  
`outcome=granted` 或 `amended_then_granted` 且缺陷类型对得上：对**同类策略**最多 **+8** 稳妥分，摘要须点名 `case_id`。库空、对不上、或只有 pending：**不得**加分。向量分只表示「像旧案」，不是授权预测。

#### 选定（禁止裸 argmax）

主目标仍是申请人利益：**能争则争，不因缩权更好打分就改权要。**

1. 纯形式/手续 → 主策略 `补正形式`，不做创造性那套比较。  
2. 清楚性/支持且只争无法消除缺陷 → 可直接 `修改权利要求`。  
3. 创造性/新颖性等实体缺陷：  
   - 默认主策略 = `仅意见陈述`；  
   - 仅当同时满足才改为 `修改权利要求`：只争相对缩权的稳妥分差 **≥15**；通知书表明只争议题很难成立；**若有**同类命中，成功案须多为改权要且 `diff` 对得上（库空则不加这项，也不得用案例加分）；  
   - 两路稳妥分差 **<15** → 维持只争。  
4. 多条缺陷分别选定，再拼进**同一份**意见陈述（第 1 条可只争、第 2 条可改权要）。

稿头写：各条主策略 + 一句选用理由（含分差是否过门槛）。落选策略的稳妥分/保范围分只进第 5 步摘要，不单独成稿。

### 4. 生成草稿（约束）

- **逐条**对应通知书条目编号。  
- 引用命中案例时写 `case_id` + 为何可参考 + **差异**。  
- 若本份策略含修改：每处修改须指向说明书可支持位置（未知则标「待发明人指认段落」）。  
- 落盘：先建本轮 `outputs/oa/{案件}/{YYYYMMDD-HHMMSS}/`，草稿写 `意见陈述草稿_{时间戳}.md`（gitignore）。**换策略重出时另存新时间戳，不覆盖上一份。**  
- 稿头写明：`strategy`（主策略）+ 一句理由。

### 4.5 对照表（新颖性/创造性且通知书列了对比文件）

形式缺陷、清楚性、无对比文件：**跳过**。有 D 号的实体缺陷才做。

1. 对照表与草稿写进**同一会话目录** `outputs/oa/{案件}/{会话}/`。  
2. 导出用本包副本 `write_intake.py`、`emit_chart.py`（同目录还有 `highlights.py`、`xlsx_minimal.py`）。改对照包时覆盖本包同名文件。  
3. 三件套已在通知书或本申请里：直接写入 intake。  
4. 写入 intake 并导出：

```bash
python skills/patent-oa/tools/write_intake.py --into {OA会话目录} --json {intake.json}
python skills/patent-oa/tools/emit_chart.py --json {OA会话目录}/_payload.json --into {OA会话目录}
```

5. payload：`scene` 固定 `oa`；`rejections` 每条含 `item`（如第1条）、`statute`、`feature_ids`、`column_ids`、`examiner_view`（摘审查员原意）。xlsx 自动加「驳回映射」页。  
6. 对照表、`Fk`、覆盖强弱只留在 xlsx。意见陈述草稿和 Word 不写这些。对话摘要只给 xlsx 路径。

### 5. 事后摘要（简短，不挡流程）

草稿落盘后，对话里只给一段摘要（约十行内）。至少包括：

- 本稿路径与各条主策略（及是否因分差≥15 才改选缩权）  
- 若做了对照表：xlsx 路径（驳回映射在表内，不贴进对话）  
- 同点比较过的其他路：稳妥分/保范围分（标明**相对分，非授权率**）各一句  
- 命中案例 `case_id`（若有）  
- **本稿为内部草稿，须复核后递交**  
- 迭代：用户可指定策略重出（如「第 1 条改成修改权利要求再出一稿」）→ 重复第 4 步，另存新文件；可多次。  
- 本步只出草稿 md。Word 见第 6 步。  
- 摘要之后按 **`skills/patent-oa/prompts/soft_nudge.md`** 决定是否加库厚度提示（先 `--inventory`；不入草稿正文）。

### 6. 确认采纳 → 意见陈述正文 Word（须用户点名）

仅当用户明确采纳某一份草稿（「用这一稿」「出 Word」「可以定稿」「采纳」等）后才做。

1. 以**被采纳的那份** `意见陈述草稿_*.md` 为来源；另存同一会话目录 `意见陈述_{时间戳}.md`（不覆盖草稿）。  
2. **`Read`** `skills/patent-oa/assets/opinion_statement.md`，按模板写递交正文：著录表 + 逐条答复 + 修改说明 + 请求 + 附件。  
3. 递交稿只写给审查员看的话：不写内部 `strategy`、相对分、`case_id`、换策略说明、对照表、`Fk`、覆盖强弱。对比文件用公开号。  
4. 缺申请号 / 发明名称 / 通知书名称时先问用户补全，**禁止编造**。发文日未知写「见通知书」。未改申请文件则第三节写「本申请文件未作修改。」  
5. **不做**官方电子申请表格，**不**自动排版权利要求替换页（附件可只列「权要替换页另行准备」）。  
6. 用本包脚本出 Word：

```bash
python skills/patent-oa/tools/emit_opinion_docx.py \
  -i outputs/oa/{案件}/{会话}/意见陈述_{时间戳}.md
# → 同目录同名 .docx；机读 DOCX: ok=1
```

7. 对话交代 Word 路径，并写明：须代理人复核后递交；旧草稿 md 保留。用户再改策略 → 回到第 4 步另存草稿，**再确认**才出新 Word。
