# 配置用户自己的客户端

公开包没有原 PatSeek 客户端或授权。请自行从合法渠道取得客户端和其依赖，核实使用许可、兼容接口与导入时的行为。服务方入口为 [PatSeek](https://patseek.cn)，本说明不承诺具体下载地址、API 路径或收费标准。

1. 在本技能目录创建本地 `vendor/`，把所获 Python 客户端及必要依赖放入其中。该目录已忽略，勿提交第三方代码、Key 或案件数据。`vendor/` 本身不能为符号链接；客户端真实路径必须在其内部，不能指向适配器自身。
2. 设置 `PATSEEK_CLIENT_PATH` 为该 `.py` 文件的绝对路径。本变量只指定文件，不是 API Key。客户端、`vendor/` 及至本技能根的目录须由当前用户拥有，不可被组或其他用户写入；必要时由安装者调整本地权限。本适配器不擅自改权限。
3. 客户端须提供可调用的 `load_cache`、`save_cache`、`recent_calls`、`log_call`、`throttle`、`main`，并支持运行期 `API_KEY`、`CALL_LOG_DISABLED`。适配器不会猜测新接口或使用另一套服务。接口变化时先停止查询并由使用者核实兼容性。
4. 按工作台安装说明配置凭据并从其安全包装器调用。付费查询须继续遵守工作台的案件、查询摘要及预算控制。使用包装器的 `--query-file` 或 `--query-stdin` 输入，不能把原始查询放在系统 argv，也不能把 Key 当参数。

示意配置只包含路径，无凭据：

```bash
export PATSEEK_CLIENT_PATH="/absolute/path/to/skills/patseek-patent-search/vendor/client.py"
```

适配器模块导入时不会读取或加载 vendor。只有工作台注入当前 Key、禁用存储标记及替换全部五个 no-store hooks 后，`main()` 才会在当前进程内加载它，验证接口、转交 hooks 与参数并调用 `main()`。结束时清空双方 `API_KEY` 并恢复进程参数和标准流；不会创建新进程。no-store 仅覆盖约定 hooks，不能约束第三方代码绕开这些 hooks 的行为。

直接运行 `python3 scripts/patseek_client.py --help` 只显示适配器说明；其他直接调用返回非零，提示使用工作台。缺配置或运行失败不会伪装为成功。若外部调用已开始后失败，费用及任务状态可能需要向服务方核实，勿自动重试。

该原创适配器采用 MIT；用户客户端保留其原有许可和使用条件，不能据此获得再分发权。免费 CNIPA 检索另见 `patent-search`。
